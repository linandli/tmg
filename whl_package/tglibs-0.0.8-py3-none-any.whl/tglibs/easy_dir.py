# -*- coding: utf-8 -*-

"""
目录操作的简单方法
"""

import os


def mkdir(path):
    """
    递归的创建目录
    """
    path_list = os.path.abspath(path).split(os.sep)
    r_path = '{}{}'.format(path_list.pop(0), os.sep)
    while path_list:
        r_path = os.path.join(r_path, path_list.pop(0))
        if not os.path.exists(r_path):
            os.mkdir(r_path)
    return path


def join(*path):
    """
    连接路径，其中第一个作为目录路径
    """
    base = path[0]
    if len(path) > 1:
        base = os.path.dirname(base) if os.path.isfile(base) else base
    return os.path.abspath(os.path.join(base, *path[1:]))
