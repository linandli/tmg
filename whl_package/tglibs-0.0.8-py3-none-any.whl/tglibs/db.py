# -*- coding: utf-8 -*-

from tglibs.singleton import Singleton
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker


class DB(metaclass=Singleton):
    def __init__(self, database, password, host='localhost', port=5432, echo=False):
        self.conn_string = 'postgresql+psycopg2://postgres:%s@%s:%s/%s' % (password, host, port, database)
        self.engine = create_engine(self.conn_string, echo=echo)

    def new(self):
        return self._DB(self.engine)

    class _DB:
        def __init__(self, engine):
            self.engine = engine
            self.session_class = self.session_class = scoped_session(sessionmaker(bind=self.engine))
            self._session = None

        @property
        def session(self):
            if self._session is None:
                self._session = self.session_class()
            return self._session

        def __enter__(self):
            return self.session

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.session.close()
            self._session = None


class MysqlDB(metaclass=Singleton):
    def __init__(self, user='rootadmin', database='environmental_data', password='Mysql123', host='database.mysql.zhangbei.rds.aliyuncs.com', port=3306, echo=False):
        self.conn_string = 'mysql+pymysql://%s:%s@%s:%s/%s' %(user, password, host, port, database)
        self.engine = create_engine(self.conn_string, echo=echo)

    def new(self):
        return self._MysqlDB(self.engine)

    class _MysqlDB:
        def __init__(self, engine):
            self.engine = engine
            self.session_class = self.session_class = scoped_session(sessionmaker(bind=self.engine))
            self._session = None

        @property
        def session(self):
            if self._session is None:
                self._session = self.session_class()
            return self._session

        def __enter__(self):
            return self.session

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.session.close()
            self._session = None
