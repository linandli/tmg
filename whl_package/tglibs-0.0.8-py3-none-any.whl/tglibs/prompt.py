def get_input(prompt, method=None, default=None, valid=None):
    """
    用于在shell界面获取用户输入的方法
    :param prompt: 提示信息
    :param method: 返回值的处理方法
    :param default: 默认返回值
    :param valid: 判断输入是否合法的方法
    :return: 用户输入
    """
    result = ''
    if default is None:
        prompt = '{}<EXIT>：'.format(prompt)
    else:
        prompt = '{}【默认 - {}】<EXIT>：'.format(prompt, default)
    while result == '':
        result = input(prompt).strip()
        if result.lower() == 'exit':
            exit(0)
        result = result or default or ''
        if method:
            try:
                result = method(result)
            except:
                result = ''
        if valid and not valid(result):
            result = ''
    return result
