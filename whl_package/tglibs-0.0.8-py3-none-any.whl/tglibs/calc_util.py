# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from scipy import interpolate


def time_series_interpolate(series):
    """
    序列插值
    :param series: Pandas.Series
    :return: 新插入的值序列
    """
    if isinstance(series, pd.Series):
        index = array_interpolate(series.values)
        if index is not None:
            return series[index]


def array_interpolate(arr):
    """
    数组插值
    :param arr: numpy.array
    :return: 新插入值的索引
    """
    x = np.arange(len(arr))
    not_nan = np.logical_not(np.isnan(arr))
    x_break = x[not_nan]
    if len(x_break) < 2:
        return
    sl = np.s_[x_break[0]:x_break[-1]]
    if not_nan[sl].all():
        return
    y_break = arr[not_nan]
    ipf = interpolate.interp1d(x_break, y_break)
    arr[sl] = ipf(x[sl])
    return x[sl][~not_nan[sl]]


def time_series_fb_fill(series):
    """
    两端填充序列
    :param series: 待填充Series
    :return: 填充的新值序列
    """
    index = series[series.isnull()].index
    series.fillna(method='ffill', inplace=True)
    series.fillna(method='bfill', inplace=True)
    return series[index]


def merge_serial(main_series, minor_series, name=None):
    """
    合并两个Series，当主Series中的值为nan，则用从Series的值填充
    :param main_series: 主Series
    :param minor_series: 从Series
    :param name: 返回Series命名，如果为None，则用主Series名称
    :return: Series
    """
    name = name or main_series.name
    main_name = '{}_x'.format(name)
    minor_name = '{}_y'.format(name)
    main_series = pd.Series(main_series, name=main_name)
    minor_series = pd.Series(minor_series, name=minor_name)
    frame = pd.merge(pd.DataFrame(main_series), pd.DataFrame(minor_series),
                     'outer', left_index=True, right_index=True)
    return pd.Series(frame[main_name].fillna(frame[minor_name]), name=name)


def merge_frame(main_frame, minor_frame):
    """
    合并两个DataFrame
    :param main_frame: 主DataFrame
    :param minor_frame: 从DataFrame
    :return: DataFrame
    """
    frame = main_frame.copy()
    for c in minor_frame.columns:
        s = frame[c] if c in frame.columns else pd.Series(index=frame.index)
        frame[c] = merge_serial(s, minor_frame[c])
    return frame


def get_continuous_region(arr, continuous_num=0, condition=lambda x: x == 0):
    """
    计算数组每一行符合条件的连续区间
    :param arr: 二维数组
    :param continuous_num: 连续区间的最小尺寸
    :param condition: 条件
    :return: list，元素个数与arr行数相同，每个元素为n*3的数组，
             n表示区间数量，3个维度分别为[起始位置, 结束位置, 连续区间长度]
    """
    arr = np.asarray(arr)
    assert 1 <= arr.ndim <= 2
    if arr.ndim == 1:
        arr = np.asarray([arr])
    index = np.r_[1:arr.shape[1]]
    t_arr = (condition(arr)).astype(int)
    d_arr = np.diff(t_arr)
    result = []
    for i in range(len(d_arr)):
        row = d_arr[i]
        r_u, r_d = index[row > 0], index[row < 0]
        if len(r_u) < len(r_d):
            r_u = np.r_[0, r_u]
        elif len(r_u) > len(r_d):
            r_d = np.r_[r_d, arr.shape[1]]
        else:
            if len(r_u) == 0:
                if t_arr[i][0] == 1:
                    r_u = np.r_[0, r_u]
                    r_d = np.r_[r_d, arr.shape[1]]
            elif r_u[0] > r_d[0]:
                r_u = np.r_[0, r_u]
                r_d = np.r_[r_d, arr.shape[1]]
        interval = np.c_[r_u, r_d, r_d - r_u]
        result.append(interval[interval[:, -1] >= continuous_num])
    return result


class CalcUtil:
    @staticmethod
    def time_series_interpolate(series):
        return time_series_interpolate(series)

    @staticmethod
    def array_interpolate(arr):
        return array_interpolate(arr)

    @staticmethod
    def time_series_fb_fill(series):
        return time_series_fb_fill(series)

    @staticmethod
    def merge_serial(main_series, minor_series, name=None):
        return merge_serial(main_series, minor_series, name)

    @staticmethod
    def merge_frame(main_frame, minor_frame):
        return merge_frame(main_frame, minor_frame)

    @staticmethod
    def get_continuous_region(arr, continuous_num=0, condition=lambda x: x == 0):
        return get_continuous_region(arr, continuous_num, condition)
