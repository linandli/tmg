# -*- coding: utf-8 -*-

"""
提供一个专用于时间序列预测的数据预处理器类
"""

import numpy as np
import pandas as pd
from tglibs.calc_util import get_continuous_region


class TimeSeqPreprocessor:
    """
    时间序列预测的数据预处理器类
    该类提供一个容器Frame，存放所有用到的时间序列数据
    """
    def __init__(self, freq, left_seq_len, right_seq_len):
        """
        初始化
        :param freq: Pandas的风格周期描述字符串
        :param left_seq_len: 预测的输入时间长度（输入点数）
        :param right_seq_len: 预测的输出时间长度（输出点数）
        """
        self.freq = freq
        self._left_seq_len = left_seq_len
        self._right_seq_len = right_seq_len
        self._total_seq_len = left_seq_len + right_seq_len
        self._frame = None
        self._left_columns = []
        self._right_columns = []
        self._output_columns = []

    def add_time_frame(self, frame, left=False, right=False, output=False):
        """
        向容器添加一组数据，数据的index必须为时间
        :param frame: 添加的数据，Series或DataFrame
        :param left: True表示添加的数据用于预测输入，该输入表示预测时间前的时间序列数据
        :param right: True表示添加的数据用于预测输入，该输入表示预测时间段的序列数据
        :param output: True表示添加的数据用于预测输出
        """
        assert frame.index.dtype == 'datetime64[ns]'
        assert any([left, right, output])
        frame = pd.DataFrame(frame, dtype=float)
        cn = 0 if self._frame is None else len(self._frame.columns)
        columns_index = list(range(cn, cn + len(frame.columns)))
        frame = frame.resample(self.freq).first()
        if self._frame is None:
            self._frame = frame
        else:
            self._frame = self._frame.merge(frame, left_index=True, right_index=True, sort=True)
        if left:
            self._left_columns.extend(columns_index)
        if right:
            self._right_columns.extend(columns_index)
        if output:
            self._output_columns.extend(columns_index)

    @property
    def index(self):
        return None if self._frame is None else self._frame.index

    @property
    def frames(self):
        """
        返回连续的数据片段列表
        """
        frame = self._frame.resample(self.freq).first()
        rgs = get_continuous_region(np.all(~np.isnan(frame.values), axis=1), self._total_seq_len, lambda x: x)[0]
        return [self._frame[rg[0]:rg[1]] for rg in rgs]

    @property
    def data(self):
        """
        返回移动窗口截取的全部数据
        """
        result = []
        for frame in self.frames:
            data = frame.values
            data = np.concatenate([data[i:data.shape[0] - self._total_seq_len + i + 1]
                                   for i in range(self._total_seq_len)], axis=1) \
                .reshape([-1, self._total_seq_len, data.shape[1]])
            result.append(data)
        return np.concatenate(result)

    def get_xy(self):
        """
        返回用于训练的x1，x2和y
        """
        data = self.data
        return data[:, :-self._right_seq_len, self._left_columns], \
               data[:, self._left_seq_len:, self._right_columns], \
               data[:, self._left_seq_len:, self._output_columns]
