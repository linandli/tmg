# -*- coding: utf-8 -*-

import os
import sys
import logging
from logging import StreamHandler
from logging.handlers import TimedRotatingFileHandler
from tglibs.config import ConfigBase, ConfigProperty
from tglibs.easy_dir import mkdir
from tglibs.singleton import Singleton


def get_log_config(filename=None, section=None):
    section = section or 'DEFAULT'

    class LogConfig(ConfigBase):
        log_name = ConfigProperty(str, section, 'default')
        log_level = ConfigProperty(str, section, 'info')
        log_format = ConfigProperty(str, section, '{asctime}\n'
                                                  '[{levelname}][{module}]'
                                                  '[PID: {process}][TID: {thread}]'
                                                  ' - {message}')
        log_stream = ConfigProperty(bool, section, False)
        log_stream_out = ConfigProperty(str, section, 'stderr')
        log_file = ConfigProperty(str, section)
        log_file_when = ConfigProperty(str, section, 'h')
        log_file_interval = ConfigProperty(int, section, 1)
        log_file_backup_count = ConfigProperty(int, section, 0)
        log_file_encoding = ConfigProperty(str, section, 'utf-8')

        def __init__(self):
            super(LogConfig, self).__init__(filename)

        @property
        def p_log_level(self):
            return {'info': logging.INFO,
                    'error': logging.ERROR,
                    'debug': logging.DEBUG,
                    'warning': logging.WARNING}.get(self.log_level.lower(), logging.INFO)

        @property
        def p_log_stream_point(self):
            return {'stderr': sys.stderr, 'stdout': sys.stdout}.get(self.log_stream_out.lower(), sys.stderr)

    return LogConfig()


class Log(metaclass=Singleton):
    @classmethod
    def from_config(cls, config):
        obj = cls()
        obj._logger = logging.getLogger(config.log_name)
        obj._logger.setLevel(config.p_log_level)
        obj._logger.handlers.clear()
        log_format_str = config.log_format
        log_format = logging.Formatter(log_format_str, style='{')

        if config.log_stream:
            log_handler = StreamHandler(config.p_log_stream_point)
            log_handler.setFormatter(log_format)
            obj._logger.addHandler(log_handler)

        if config.log_file:
            log_file = os.path.abspath(config.log_file)
            mkdir(os.path.dirname(log_file))
            log_handler = TimedRotatingFileHandler(log_file,
                                                   when=config.log_file_when,
                                                   interval=config.log_file_interval,
                                                   backupCount=config.log_file_backup_count,
                                                   encoding=config.log_file_encoding)
            log_handler.setFormatter(log_format)
            obj._logger.addHandler(log_handler)
        return obj

    @property
    def logger(self):
        return self._logger


if __name__ == '__main__':
    c = get_log_config()
    c.load()
    logger = Log.from_config(c).logger
    logger.info('123')
    logger.error('姜策')
