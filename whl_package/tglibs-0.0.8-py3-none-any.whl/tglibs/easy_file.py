# -*- coding: utf-8 -*-

"""
文件操作的简单方法
"""

import os
import json
import pickle
from bz2 import BZ2File
from contextlib import closing


def del_file(fullname):
    """
    删除文件
    """
    if os.path.exists(fullname):
        os.remove(fullname)


def get_tmp_name(fullname):
    """
    获取临时文件名
    """
    return '{}.tmp'.format(os.path.abspath(fullname))


def read_bz2(fullname, encoding='utf-8'):
    """
    从压缩文件中读取文本内容
    """
    if os.path.exists(fullname):
        with closing(BZ2File(fullname, 'rb')) as f:
            return f.read().decode(encoding)


def write_bz2(fullname, txt, encoding='utf-8'):
    """
    将文本存入压缩文件
    """
    temp_name = get_tmp_name(fullname)
    del_file(fullname)
    with closing(BZ2File(temp_name, 'wb')) as f:
        f.write(txt.encode(encoding))
    os.rename(temp_name, fullname)
    return fullname


def read_txt(fullname, encoding='utf-8'):
    """
    读取文本文件
    """
    if os.path.exists(fullname):
        with open(fullname, encoding=encoding) as f:
            return f.read()


def write_txt(fullname, txt, encoding='utf-8'):
    """
    写文本文件
    """
    temp_name = get_tmp_name(fullname)
    del_file(fullname)
    with open(temp_name, 'w', encoding=encoding) as f:
        f.write(txt)
    os.rename(temp_name, fullname)
    return fullname


def read_obj(fullname):
    """
    读文件中的对象
    """
    if os.path.exists(fullname):
        with closing(BZ2File(fullname, 'rb')) as f:
            return pickle.load(f)


def write_obj(fullname, obj):
    """
    写对象到文件中
    """
    temp_name = get_tmp_name(fullname)
    del_file(fullname)
    with closing(BZ2File(temp_name, 'wb')) as f:
        pickle.dump(obj, f)
    os.rename(temp_name, fullname)
    return fullname


def backup(fullname, backup_path, new_name=None):
    """
    备份文件
    """
    if os.path.exists(fullname):
        filename = new_name or os.path.basename(fullname)
        target = os.path.join(backup_path, filename)
        del_file(target)
        os.rename(fullname, target)
        return target
