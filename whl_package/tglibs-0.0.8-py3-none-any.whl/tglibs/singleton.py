# -*- coding: utf-8 -*-

"""
实现类的单例模式

Exsample:

class Sing(metadata=Singleton):
    pass
"""


class Singleton(type):
    def __init__(cls, name, bases, _dict):
        super(Singleton, cls).__init__(name, bases, _dict)
        cls.instance = None

    def __call__(cls, *args, **kwargs):
        if cls.instance is None:
            cls.instance = super(Singleton, cls).__call__(*args, **kwargs)
        return cls.instance


if __name__ == '__main__':
    class Sing(metaclass=Singleton):
        pass


    a = Sing()
    b = Sing()
    assert a is b
