# -*- coding: utf-8 -*-

from PyQt5 import QtWidgets as _qtw

getOpenFileName = _qtw.QFileDialog.getOpenFileName
getSaveFileName = _qtw.QFileDialog.getSaveFileName
warning = _qtw.QMessageBox.warning
information = _qtw.QMessageBox.information
question = _qtw.QMessageBox.question
