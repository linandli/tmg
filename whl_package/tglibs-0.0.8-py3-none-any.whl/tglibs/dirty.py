# -*- coding: utf-8 -*-

"""
用于定义污染对象的套件
"""


class DirtyDecorator:
    def __init__(self):
        self.name = None

    def __get__(self, instance, owner):
        return getattr(instance, '_{}'.format(self.name), None)

    def __set__(self, instance, value):
        old_value = getattr(instance, '_{}'.format(self.name), None)
        if old_value != value:
            setattr(instance, '_{}'.format(self.name), value)
            if not instance.dirty:
                setattr(instance, 'old_{}'.format(self.name), old_value)
            instance.set_dirty()


class Dirty:
    def __init__(self):
        self._dirty = False
        for name, prop in ((name, prop) for name, prop in self.__class__.__dict__.items()
                           if isinstance(prop, DirtyDecorator)):
            prop.name = name
            setattr(self, '_{}'.format(prop.name), None)
            setattr(self, 'old_{}'.format(prop.name), None)

    @property
    def dirty(self):
        return self._dirty \
               or any((prop.dirty for prop in self.__dict__.values() if isinstance(prop, Dirty)))

    def set_dirty(self):
        self._dirty = True

    def clear_dirty(self):
        self._dirty = False
        for prop in (prop for prop in self.__class__.__dict__.values() if isinstance(prop, DirtyDecorator)):
            setattr(self, 'old_{}'.format(prop.name), getattr(self, '_{}'.format(prop.name)))
        for prop in (prop for prop in self.__dict__.values() if isinstance(prop, Dirty)):
            prop.clear_dirty()


class DirtyList(list, Dirty):
    def __init__(self, seq=()):
        super(DirtyList, self).__init__(seq)
        Dirty.__init__(self)

    def append(self, p_object):
        self.set_dirty()
        return super(DirtyList, self).append(p_object)

    def clear(self):
        self.set_dirty()
        return super(DirtyList, self).clear()

    def extend(self, iterable):
        self.set_dirty()
        return super(DirtyList, self).extend(iterable)

    def insert(self, index, p_object):
        self.set_dirty()
        return super(DirtyList, self).insert(index, p_object)

    def pop(self, index=None):
        self.set_dirty()
        return super(DirtyList, self).pop(index)

    def remove(self, value):
        self.set_dirty()
        return super(DirtyList, self).remove(value)

    def reverse(self):
        self.set_dirty()
        return super(DirtyList, self).reverse()

    def sort(self, key=None, reverse=False):
        self.set_dirty()
        return super(DirtyList, self).sort(key=key, reverse=reverse)

    def __add__(self, *args, **kwargs):
        self.set_dirty()
        return super(DirtyList, self).__add__(*args, **kwargs)

    def __delitem__(self, *args, **kwargs):
        self.set_dirty()
        return super(DirtyList, self).__delitem__(*args, **kwargs)

    def __setitem__(self, *args, **kwargs):
        self.set_dirty()
        return super(DirtyList, self).__setitem__(*args, **kwargs)

    @property
    def dirty(self):
        return super(DirtyList, self).dirty or any((item.dirty for item in self if isinstance(item, Dirty)))

    def clear_dirty(self):
        super(DirtyList, self).clear_dirty()
        for item in (item for item in self if isinstance(item, Dirty)):
            item.clear_dirty()
