# -*- coding: utf-8 -*-

"""
通用的数据库连接套件

Example:

config = get_sqlite_config()
config.load()
DB.from_config(config)
with DB().new() as session:
    session.query(...)


config = get_postgresql_config(section='DATABASE')
config.db_id = 'test'
config.db_name = 'postgres'
config.db_pass = 'postgres'
config.db_echo = True
DB.from_config(config)
with DB('test').new() as session:
    session.query(...)
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from tglibs.config import ConfigProperty, ConfigBase


def get_sqlite_config(filename=None, section=None):
    """
    获取一个Sqlite数据库的访问配置
    :param filename: 配置文件名称
    :param section: 配置节，如果为空则在默认节
    :return: 配置对象
    """
    section = section or 'DEFAULT'

    class SQLiteConfig(ConfigBase):
        db_id = ConfigProperty(str, section=section, default='default')
        db_name = ConfigProperty(str, section=section, default=':memory:')
        db_echo = ConfigProperty(bool, section=section, default=False)
        db_path = ConfigProperty(str, section=section)

        def __init__(self):
            super(SQLiteConfig, self).__init__(filename)

        @property
        def connection_string(self):
            return 'sqlite:///{}/{}'.format(self.db_path, self.db_name)

    return SQLiteConfig()


def get_postgresql_config(filename=None, section=None):
    """
    获取一个PostgreSql数据库的访问配置
    :param filename: 配置文件名称
    :param section: 配置节，如果为空则在默认节
    :return: 配置对象
    """
    section = section or 'DEFAULT'

    class PostgreSqlConfig(ConfigBase):
        db_id = ConfigProperty(str, section=section, default='default')
        db_name = ConfigProperty(str, section=section)
        db_user = ConfigProperty(str, section=section, default='postgres')
        db_pass = ConfigProperty(str, section=section)
        db_host = ConfigProperty(str, section=section, default='localhost')
        db_port = ConfigProperty(int, section=section, default=5432)
        db_echo = ConfigProperty(bool, section=section, default=False)

        def __init__(self):
            super(PostgreSqlConfig, self).__init__(filename)

        @property
        def connection_string(self):
            return 'postgresql+psycopg2://{}:{}@{}:{}/{}'.format(self.db_user,
                                                                 self.db_pass,
                                                                 self.db_host,
                                                                 self.db_port,
                                                                 self.db_name)

    return PostgreSqlConfig()


def get_mysql_config(filename=None, section=None):
    """
    获取一个PostgreSql数据库的访问配置
    :param filename: 配置文件名称
    :param section: 配置节，如果为空则在默认节
    :return: 配置对象
    """
    section = section or 'DEFAULT'

    class MysqlConfig(ConfigBase):
        db_id = ConfigProperty(str, section=section, default='default')
        db_name = ConfigProperty(str, section=section)
        db_user = ConfigProperty(str, section=section, default='postgres')
        db_pass = ConfigProperty(str, section=section)
        db_host = ConfigProperty(str, section=section, default='localhost')
        db_port = ConfigProperty(int, section=section, default=3306)
        db_echo = ConfigProperty(bool, section=section, default=False)

        def __init__(self):
            super(MysqlConfig, self).__init__(filename)

        @property
        def connection_string(self):
            return 'mysql+pymysql://{}:{}@{}:{}/{}'.format(self.db_user,
                                                                 self.db_pass,
                                                                 self.db_host,
                                                                 self.db_port,
                                                                 self.db_name)

    return MysqlConfig()


class DB:
    """
    数据库访问类
    
    该类的首次实例化应该由调用from_config方法并传入一个config对象完成。
    config中的db_id唯一标识一个DB对象，即相同db_id的DB对象是同一个。
    在此之后就可以以DB(db_id)形式得到对象。
    
    该类对象只保存数据库连接engine，使用时应每次调用new()方法得到一个新的对象。
    该对象可以使用with语法获得session。
    由于每次获得新的session，因此一般不用担心多线程情况下session冲突问题。
    """
    _db_dict_ = {}

    def __new__(cls, db_id='default'):
        if db_id not in cls._db_dict_:
            cls._db_dict_[db_id] = object.__new__(cls)
        return cls._db_dict_[db_id]

    @classmethod
    def from_config(cls, config):
        db = DB(config.db_id)
        db._engine = create_engine(config.connection_string, echo=config.db_echo)
        return db

    @property
    def engine(self):
        return self._engine

    def new(self):
        return self._DB(self.engine)

    class _DB:
        def __init__(self, engine):
            self.engine = engine
            self.session_class = self.session_class = scoped_session(sessionmaker(bind=self.engine))
            self._session = None

        @property
        def session(self):
            if not self._session:
                self._session = self.session_class()
            return self._session

        def close(self):
            if self._session:
                self.session.close()
                self._session = None

        def __enter__(self):
            return self.session

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.close()