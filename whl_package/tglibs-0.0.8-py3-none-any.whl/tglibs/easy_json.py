# -*- coding: utf-8 -*-

"""
json使用的简单封装
"""

from json import dumps, loads


def o2j(obj, ensure_ascii=False):
    return dumps(obj, ensure_ascii=ensure_ascii)


def j2o(txt, default=dict):
    try:
        return loads(txt)
    except:
        return default()
