# -*- coding: utf-8 -*-

"""
一个适应于常见场景的日期时间解析工具

该工具：
- 支持常见格式的日期时间字符串格式转换，日期分隔符支持-和_，时间分隔符支持:
- 支持元组方式定义日期时间转换
- 支持短年份辨认
- 支持相对时间，例如24:00或(0,0,-1)
- 时间的毫秒部分将被忽略
"""

import datetime
import re
import time as tm


class DateTimeParser:
    def __init__(self, date=None, time=None):
        self.p_date = re.compile(r'(\d+)-(\d+)-?(\d+)?')
        self.p_time = re.compile(r'(\d+):(\d+):?(\d+)?.*')
        self.datetime = datetime.datetime(1, 1, 1, 0, 0, 0)
        self.set_date(date)
        self.set_time(time)

        try:
            self.datetime_mktime = int(tm.mktime(self.datetime.timetuple()) * 1000 if self.datetime.year > 1969 else 0)
        except Exception as e:
            self.datetime_mktime = 0

    def verify_date(self, date):
        date = list(date)[0:3]

        if date[0] < 100:
            date[0] += 2000

        if date[1] < 1 or date[1] > 12:
            raise Exception('error month')

        if len(date) > 2:
            if date[2] < 1 or date[2] > 31:
                raise Exception('error day')
        return self.datetime.replace(*date)

    def verify_time(self, time):
        time = list(time)[0:3]
        if len(time) == 2:
            time.append(0)
        h = time[0] % 24
        dh, time[0] = time[0] - h, h
        m = time[1] % 60
        dm, time[1] = time[1] - m, m
        s = time[2] % 60
        ds, time[2] = time[2] - s, s
        return self.datetime.replace(hour=time[0], minute=time[1], second=time[2]) \
               + datetime.timedelta(hours=dh, minutes=dm, seconds=ds)

    def set_date(self, date):
        if isinstance(date, str):
            date = date.replace('_', '-')
            m = self.p_date.search(date)
            if m:
                self.datetime = self.verify_date(map(int, m.group().split('-')))
        elif isinstance(date, (list, tuple)):
            self.datetime = self.verify_date(date)
        elif isinstance(date, (datetime.date, datetime.datetime)):
            self.datetime = self.verify_date(date.timetuple())

        try:
            self.datetime_mktime = int(tm.mktime(self.datetime.timetuple()) * 1000 if self.datetime.year > 1969 else 0)
        except Exception as e:
            self.datetime_mktime = 0

        return self

    def set_time(self, time):
        if isinstance(time, str):
            m = self.p_time.search(time)

            if m:
                self.datetime = self.verify_time(map(lambda x: int(x) if x is not None else 0, m.groups()))
        elif isinstance(time, (list, tuple)):
            self.datetime = self.verify_time(time)
        elif isinstance(time, datetime.datetime):
            self.datetime = self.verify_time(time.timetuple()[3:6])
        elif isinstance(time, datetime.time):
            self.datetime = self.verify_time((time.hour, time.minute, time.second))
        elif isinstance(time, datetime.date):
            self.datetime = self.verify_time((0, 0, 0))

        try:
            self.datetime_mktime = int(tm.mktime(self.datetime.timetuple()) * 1000 if self.datetime.year > 1969 else 0)
        except Exception as e:
            self.datetime_mktime = 0
            
        return self


if __name__ == '__main__':
    d = DateTimeParser('1970-1-1', '00:00:00').datetime
    print(d)
    # assert d == DateTimeParser().set_date((17, 1, 1)).set_time((0, 0, -1)).datetime
    # assert d == DateTimeParser().set_date('16-12-31').set_time((24, 0, -1)).datetime
