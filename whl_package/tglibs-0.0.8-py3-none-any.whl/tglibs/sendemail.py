# -*- coding: utf-8 -*-

import smtplib
from email.mime.text import MIMEText


def send_email(to, title, content, subtype='plain', _from='service@togeek.cn',
               password='tuji2013', host='smtp.ym.163.com', port=25):
    try:
        server = smtplib.SMTP(host, port)
        code, resp = server.ehlo()
        if not (200 <= code <= 299):
            raise smtplib.SMTPHeloError(code, resp)
        if server.has_extn('auth'):
            server.login(_from, password)
        else:
            print("Server does not suport Authentication; using normal connect.")
        msg = MIMEText(content, _subtype=subtype, _charset='utf8')
        msg['Subject'] = title
        msg['From'] = _from
        msg['To'] = ';'.join(to)
        server.sendmail(_from, to, msg.as_string())
        return True
    except Exception as e:
        print('Send 发送失败！失败码：', e)
        return False


if __name__ == '__main__':
    send_result = send_email(to=['chenglinlin@togeek.cn', ], title="test_send_email", content="dddddddddd")
    if send_result:
        print('send success!')
    else:
        print('send fail!')