# -*- coding: utf-8 -*-

"""
集合常用的url处理方法
"""

from collections import OrderedDict
from urllib.parse import *
from tglibs.easy_json import o2j


def construct_url(host, path=None, query=None):
    """
    构造请求的url
    :param host: str
    :param path: str or list
    :param query: dict
    :return: str
    """
    host = host.strip('/')
    host = 'http://{}'.format(host) if not (host.startswith('http://') or host.startswith('https://')) else host
    path = path or []
    if isinstance(path, str):
        path = path.strip('/').split('/')
    url = '/'.join([host] + list(path))
    query = query or {}
    query = urlencode(query)
    return '{}?{}'.format(url, query) if query else url


def construct_data(method, header=None, body=None, json=None):
    """
    构造请求的header和body
    :param method: str
    :param header: dict
    :param body: str bytes or dict
    :param json: str or dict
    :return: dict and bytes
    """
    method = method.upper()
    methods = ['GET', 'DELETE', 'HEAD', 'OPTIONS', 'PUT', 'POST']
    assert method in methods
    header = header or {}
    header.setdefault('Accept', '*/*')
    header.setdefault('Connection', 'keep-alive')
    if method in methods[:4]:
        return header, None
    data = b''
    if body:
        header['Content-Type'] = 'application/x-www-form-urlencoded'
        data = urlencode(body) if isinstance(body, dict) else body
        data = data if isinstance(data, bytes) else data.encode()
    elif json:
        header['Content-Type'] = 'application/json'
        data = json if isinstance(json, str) else o2j(json)
        data = data.encode()
    header['Content-Length'] = len(data)
    return header, data


def get_query_value(url, qname, default=None):
    """
    获取url中指定query名称的值
    :param url: str
    :param qname: str
    :param default: str
    :return: str
    """
    url_parts = urlparse(url)
    return dict(parse_qsl(url_parts.query)).get(qname, default)


def update_url_query(url, qname, value):
    """
    更新url中指定query名称的值，返回一个新的url
    :param url: str
    :param qname: str
    :param value: object
    :return: str
    """
    url_parts = list(urlparse(url))
    query = OrderedDict(parse_qsl(url_parts[4]))
    query[qname] = value
    url_parts[4] = urlencode(query)
    return urlunparse(url_parts)


def remove_url_query(url, qname):
    """
    移除url中的query，返回一个新的url
    :param url: str
    :param qname: str
    :return: str
    """
    url_parts = list(urlparse(url))
    query = OrderedDict(parse_qsl(url_parts[4]))
    if qname in query:
        del query[qname]
    url_parts[4] = urlencode(query)
    return urlunparse(url_parts)


def add_anchor(url, anchor):
    """
    给url添加一个anchor，返回一个新的url
    :param url: str
    :param anchor: str
    :return: str
    """
    url_parts = list(urlparse(url))
    url_parts[5] = str(anchor)
    return urlunparse(url_parts)


def remove_anchor(url):
    """
    移除url中的anchor，返回一个新的url
    :param url: str
    :return: str
    """
    url_parts = list(urlparse(url))
    url_parts[5] = None
    return urlunparse(url_parts)
