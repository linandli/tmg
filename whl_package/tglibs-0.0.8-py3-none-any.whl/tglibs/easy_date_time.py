import datetime
import pandas as pd
from tglibs.date_time_parser import DateTimeParser


def construct_dates(dates, time=False):
    """
    构造一个闭区间的时间范围
    :param dates: 时间或时间区间
    :param time: 是否包含时间部分
    :return: tuple
    """
    d1, d2 = dates if isinstance(dates, (tuple, list)) else (dates, dates)
    return (DateTimeParser(d1, d1).datetime, DateTimeParser(d2, d2).datetime) \
        if time else (DateTimeParser(d1).datetime, DateTimeParser(d2).datetime)


def construct_time_index(days, freq='15T', time=False, closed=False):
    """
    构造时间索引
    :param days: 日期区间范围
    :param freq: 周期，默认为15分钟
    :param time: 日期区间范围是否包含时间部分
    :param closed: 右侧是否为闭区间
    :return: DatetimeIndex
    """
    d1, d2 = construct_dates(days, time)
    d2 = d2 if time else d2 + datetime.timedelta(days=1)
    c = None if closed else 'left'
    return pd.date_range(start=d1, end=d2, freq=freq, closed=c)
