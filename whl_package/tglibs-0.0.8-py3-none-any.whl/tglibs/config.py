# -*- coding: utf-8 -*-

"""
配置文件工具套件

Example:

class TestConfig(ConfigBase, metaclass=Singleton):
    name = ConfigProperty(str)
    age = ConfigProperty(int)
    sex = ConfigProperty(bool, default=True)
    speciality = ConfigProperty(list, 'EXT')
    family = ConfigProperty(dict, 'EXT')

    def __init__(self, filename=None):
        super(TestConfig, self).__init__(filename)
        

c = TestConfig('config.ini')
c.load()
c.name = 'Jiang Ce'
c.sex = True
c.age = 35
c.speciality.append('music')
c.speciality.append('computer')
c.family['father'] = 'JPB'
c.family['mother'] = 'PWM'
c.save()
"""

import os
from configparser import ConfigParser
from tglibs.easy_json import j2o, o2j


class ConfigProperty:
    def __init__(self, cls, section='DEFAULT', default=None):
        assert cls in [bool, str, int, float, complex, list, dict]
        self.cls = cls
        self.section = section
        self.name = None
        self.default = default or self.cls()

    @property
    def field_name(self):
        return '_{}_{}'.format(self.section, self.name)

    def from_str(self, string):
        if self.cls is str:
            return string
        elif self.cls in [int, float, complex]:
            return self.cls(string)
        elif self.cls is bool:
            return eval(string.capitalize())
        elif self.cls in [list, dict]:
            return j2o(string)

    def to_str(self, value):
        if self.cls in [bool, str, int, float, complex]:
            return str(value)
        elif self.cls in [list, dict]:
            return o2j(value)

    def __get__(self, instance, owner):
        return getattr(instance, self.field_name, self.default)

    def __set__(self, instance, value):
        setattr(instance, self.field_name, value)


class ConfigBase:
    def __init__(self, filename=None):
        for name, prop in self.iter_prop():
            prop.name = name
            setattr(self, name, prop.default)
        self.filename = filename or os.path.abspath(os.path.join(os.path.dirname(__file__), 'config.ini'))

    def iter_prop(self):
        yield from ((name, prop) for name, prop in self.__class__.__dict__.items()
                    if isinstance(prop, ConfigProperty))

    def load(self):
        if os.path.exists(self.filename):
            cp = ConfigParser()
            cp.read(self.filename, encoding='utf8')
            for name, prop in self.iter_prop():
                try:
                    setattr(self, name, prop.from_str(cp[prop.section][name]))
                except:
                    pass
        return self

    def save(self):
        cp = ConfigParser()
        for name, prop in self.iter_prop():
            if prop.section not in cp:
                cp[prop.section] = {}
            cp[prop.section][name] = prop.to_str(getattr(self, name))
        with open(self.filename, 'w', encoding='utf8') as f:
            cp.write(f)
        return self

    def __repr__(self):
        result = {}
        for name, prop in self.iter_prop():
            result.setdefault(prop.section, {})[name] = getattr(self, name)
        return repr(result)
