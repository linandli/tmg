# -*- coding: utf-8 -*-

"""
一个用Pandas Series实现的时间类数据缓存
"""

import pandas as pd
import datetime
from tglibs.date_time_parser import DateTimeParser

_caches = {}


def get_cache_cls(name='default'):
    """
    返回一个指定的Cache类
    :param name: 给定的名称相同，将返回相同的Cache类
    :return: Cache类，一个Cache类的实例对应一个以时间为index的Series
    """
    cache_cls = _caches.get(name)
    if not cache_cls:
        class _TimeDataCache:
            _caches = {}

            def __new__(cls, key, series=None, before=None, after=None):
                cache = cls._caches.get(key)
                if not cache:
                    cache = cls._caches.setdefault(key, object.__new__(cls))
                    series = series or pd.Series(index=pd.DatetimeIndex([]))
                    assert series.index.dtype == 'datetime64[ns]'
                    cache._series = series.copy()
                    cache._series.name = key
                    cache._before = before
                    cache._after = after
                return cache

            @property
            def series(self):
                return self._series

            def _propcess_range(self, time_=None, before=None, after=None):
                time_ = time_ or datetime.datetime.now()
                time_ = DateTimeParser(time_, time_).datetime
                before = before or self._before
                after = after or self._after
                if isinstance(before, int):
                    before = datetime.timedelta(days=before)
                elif isinstance(before, dict):
                    before = datetime.timedelta(**before)
                if isinstance(after, int):
                    after = datetime.timedelta(days=after)
                elif isinstance(after, dict):
                    after = datetime.timedelta(**after)
                t1 = time_ - before if isinstance(before, datetime.timedelta) else None
                t2 = time_ + after if isinstance(after, datetime.timedelta) else None
                return t1, t2

            def clear(self, time_=None, before=None, after=None):
                t1, t2 = self._propcess_range(time_, before, after)
                if t1:
                    self.series.drop(self.series.index[self.series.index < t1], inplace=True)
                if t2:
                    self.series.drop(self.series.index[self.series.index > t2], inplace=True)

            @classmethod
            def clear_all(cls, time_=None, before=None, after=None):
                for cache in cls._caches.values():
                    cache.clear(time_, before, after)

            def __setitem__(self, key, value):
                key = DateTimeParser(key, key).datetime
                self.series[key] = value

            def __getitem__(self, item):
                item = DateTimeParser(item, item).datetime
                return self.series[item]

            def get(self, item):
                item = DateTimeParser(item, item).datetime
                return self.series.get(item)

            def update(self, other):
                self.series.update(other)
                s = self.series.append(other)
                self._series = s[~s.index.duplicated()]

            def out_of_series(self, time1, time2, freq='D'):
                return [t for t in pd.date_range(time1, time2, freq=freq) if t not in self.series]

            @classmethod
            def out_of_frame(cls, time1, time2, freq='D'):
                frame = cls.to_frame()
                return [t for t in pd.date_range(time1, time2, freq=freq) if t not in frame.index]

            @classmethod
            def from_frame(cls, frame, before=None, after=None):
                for c in frame.columns:
                    cls(c, before=before, after=after).update(frame[c])

            @classmethod
            def to_frame(cls, columns=None):
                columns = columns or list(cls._caches.keys())
                return pd.concat([cls(c).series for c in columns], axis=1) if columns \
                    else pd.DataFrame(index=pd.DatetimeIndex([]))

        _caches[name] = cache_cls = _TimeDataCache
    return cache_cls


TimeDataCache = get_cache_cls()
